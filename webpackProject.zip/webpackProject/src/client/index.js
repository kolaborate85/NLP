import { handleSubmit } from './js/formHandler'
import './styles/_index.scss';

export {
    handleSubmit
   }